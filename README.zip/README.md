﻿# sprint_11_github.io
</h2>ver 0.0.1</h2>

<h3>ИНСТРУКЦИЯ</h3>
Для проверки работы необходимо перейти по сслылке: 

https://github.com/vladimirKms/diplom.io/pull/2



