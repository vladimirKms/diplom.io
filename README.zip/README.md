﻿# diplom.io
</h2>ver 0.0.2</h2>
>>>>>> master
<h3>ИНСТРУКЦИЯ</h3>
Для проверки работы  необходимо перейти по ссылке:
https://github.com/vladimirKms/diplom.io/pull/4
